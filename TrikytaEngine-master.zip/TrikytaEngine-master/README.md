# TrikytaEngine
## Introduction
TrikytaEngine is lightweight 2D game engine created in C++ using SDL library and still under development stage.

## Current Features
Currently the engine features are limited to:
!(Some are not fully implmented yet)!
* Sprites creation
* Animations
* Engine Basics
* Inputs
* Physics
* Tiled Maps
* Events

## Coming Features

* Networking (using client/server)
* UI

## A lit bit about me
I'm 20 years old guy started programming using LUA at age of 14, then I worked as freelancer using LUA for sometime,Then I moved to several amount of languages like Java, PHP, C, C++. I'm interested more in C++, Thats why i used it in more than a project including (2D, 3D game, multiplayer games, and even softwares).

