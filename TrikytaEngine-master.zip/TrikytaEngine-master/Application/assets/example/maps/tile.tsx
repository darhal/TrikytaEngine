<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="tile" tilewidth="128" tileheight="128" tilecount="25" columns="5">
 <image source="tile.png" width="640" height="640"/>
</tileset>
